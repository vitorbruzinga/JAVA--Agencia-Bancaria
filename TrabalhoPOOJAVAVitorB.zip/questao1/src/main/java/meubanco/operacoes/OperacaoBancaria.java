package meubanco.operacoes;

public interface OperacaoBancaria {

 public void realizar();

}

