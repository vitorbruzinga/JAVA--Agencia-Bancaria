package meubanco.operacoes;

public abstract class OperacaoMesmoBanco implements OperacaoBancaria{

    public abstract void realizar();

}
