package outrobanco;

import meubanco.operacoes.OperacaoBancaria;

public abstract class OperacaoOutroBanco implements OperacaoBancaria {
    public abstract void realizar();
}
