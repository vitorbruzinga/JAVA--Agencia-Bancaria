package meubanco.funcionarios;

public class EscriturarioCaixa  extends Funcionario{

    //*Construtor referencia da superclasse Funcionario
    public EscriturarioCaixa(String nomeDoNovoFuncionario) {
        super(nomeDoNovoFuncionario);
    }

}
