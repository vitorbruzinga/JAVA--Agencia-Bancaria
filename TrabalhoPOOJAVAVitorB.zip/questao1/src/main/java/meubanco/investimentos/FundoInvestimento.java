package meubanco.investimentos;

public class FundoInvestimento extends Investimento {

    //*Construtor referencia da superclasse Investimento
    public FundoInvestimento(float novoCapital, float novaPorcentagemLucro) {
        super(novoCapital, novaPorcentagemLucro);
    }
}
