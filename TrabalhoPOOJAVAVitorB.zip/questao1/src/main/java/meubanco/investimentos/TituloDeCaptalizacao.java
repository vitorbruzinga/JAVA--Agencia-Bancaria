package meubanco.investimentos;

public class TituloDeCaptalizacao extends Investimento {

    //*Construtor referencia da superclasse Investimento
    public TituloDeCaptalizacao(float novoCapital, float novaPorcentagemLucro) {
        super(novoCapital, novaPorcentagemLucro);
    }
}
