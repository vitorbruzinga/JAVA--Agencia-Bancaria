package meubanco.contas;

import meubanco.clientes.Cliente;

public class ContaCorrente extends Conta {

    //*Construtor referencia da superclasse Conta
   public ContaCorrente(Cliente cliente, double valor) {

    }

}
