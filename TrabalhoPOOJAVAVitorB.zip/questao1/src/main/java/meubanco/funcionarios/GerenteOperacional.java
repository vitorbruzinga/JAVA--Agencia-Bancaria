package meubanco.funcionarios;

public class GerenteOperacional extends Funcionario {

    //*Construtor referencia da superclasse Funcionario
    public GerenteOperacional(String nomeDoNovoFuncionario) {
        super(nomeDoNovoFuncionario);
    }

}
