package meubanco.funcionarios;;

public class GerenteDeRelacionamento extends Funcionario {

    //*Construtor referencia da superclasse Funcionario
    public GerenteDeRelacionamento(String nomeDoNovoFuncionario) {
        super(nomeDoNovoFuncionario);
    }
    
}
