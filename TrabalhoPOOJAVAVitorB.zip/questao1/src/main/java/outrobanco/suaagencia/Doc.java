package outrobanco.suaagencia;

import meubanco.contas.Conta;
import outrobanco.OperacaoOutroBanco;

import java.util.Scanner;

public class Doc extends OperacaoOutroBanco {

    //*Declaracao de variaveis e criacao de objetos pedidos no comando do exercicio 14
protected double valor;
protected String confirmacao;
Conta contaCredito=new Conta(new Conta());
Conta contaDebito=new Conta(new Conta());
public final double TARIFA=10;
double valorFinal=valor+TARIFA;

//*Criacao do objeto ler da classe Scanner para receber dados do teclado(do usuario)
Scanner ler= new Scanner(System.in);

    public void realizar() {

        //*Apresentação no caixa eletronico
        System.out.println("Realize aqui sua opcao de Doc:\n");

        //*Entrada e saida dos dados necessarios para o Doc
        System.out.println("Primeiramente, informe o numero da Conta de origem da transferencia Doc:\n");
        System.out.println("Agora, informe se essa conta é uma contaCredito ou ContaDebito: \n");
        System.out.println("Informe o numero da Conta de destino da transferencia doc: \n");

        System.out.println("Digite o valor o qual deseja transferir: \n");
        valor=ler.nextDouble();


        //**Ressalvas a respeito da Tarifa e confirmacao do usuario quando ao valor da transferencia e o valor total
        System.out.println("AVISO! NESSE TIPO DE TRANSFERENCIA, HA UMA TARIFA DE 10 REAIS.");
        System.out.println("ENTAO SUA TRANSFERENCIA LHE TERA UM CUSTO DE: "+valorFinal+" Reais! \n");
        System.out.println("Caso esteja de acordo com o valor da tarifa, e o valor que deseja transferir seja de "+valor+" reais, confirme teclando 's' \n");
        confirmacao= ler.next();

        //*estrutura condicional que depende da confirmacao do cliente quanto ao valor do saque e fim do programa
        if (confirmacao=="s"){
            System.out.println("Operacao concluida! Foi realizada uma transferencia Doc no valor de: "+valor+" reais, que somado ao valor da tarifa lhe custou no total: "+valorFinal+" reais! \n");
        }
        else {
            System.out.println("");
        }
    }
}
